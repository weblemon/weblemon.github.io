# 项目的注意要点

1. 要兼容样式，所有的样式都必须写到单独的文件当中

respond.js 它是通过ajax来处理媒介查询的
如果不是在单独的文件中，ajax就请求不到那个css文件，那就处理不了

2. 在开发时，必须通过http环境来访问
3. 所有的样式必须添加到 以下respond.min.js之前link
```html
<!--[if lt IE 9]>
  <script src="js/lib/html5shiv/html5shiv.min.js"></script>
  <script src="js/lib/respond.js/respond.min.js"></script>
 <![endif]-->
```
4. 所有css文件后面立马添加上面的脚本（页面不会闪烁）