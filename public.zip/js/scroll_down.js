$(function(){
	setInterval(function(){
		$('.scroll-down .icon .glyphicon-menu-down').fadeToggle(1000)
	},1000)
})